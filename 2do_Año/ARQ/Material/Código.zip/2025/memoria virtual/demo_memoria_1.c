#include <stdio.h>

int a=10;

int main(){
        printf("a=%d, dirección de a=%p\n", a, &a);
        return 0;
}

