#include <stdio.h>

int b=20;

int main(){
        printf("b=%d dirección de b=%p\n", b, &b);
        return 0;
}


